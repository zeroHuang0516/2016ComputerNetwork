﻿1. 學號：b03901156
2. 姓名：黃于瑄
3. 使用之程式語言：< C >
4. 使用之編譯器：< GNU gcc >
5. 檔案壓縮方式: <zip>
6. 各檔案說明：
	 b03901156_pj2/main/src : source files including project2
	 b03901156_pj2/main/bin  : binary files including project2
	 b03901156_pj2/main/Makefile : Makefile
	 b03901156_pj2/main/readme.txt : the file explains how the program executes
	 b03901156_pj2/main/Report.pdf : report

7. 編譯方式說明：        	
	 請在main的目錄下，鍵入make all指令，即可完成編譯，
	 在main的目錄下產生 project2 執行檔
	 如果要重新編譯，請先執行 make clean 再執行一次 make all
	
8. 執行、使用方式說明：
   主程式：
   編譯完成後，在main的目錄下產生 project2 執行檔
   執行檔的命令格式為：
	./project2 [filename]

